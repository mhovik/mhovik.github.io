// TODO: How would we break this UI down into functions?
"use strict";
(function() {
  // 1. attach window load listener
    // TODO

  function init() {
    // 2. attach answer-btn click listener
    // TODO
  }

  // When answer-btn is clicked, the number of green skittles should be displayed
  // (make sure to unhide the p element by removing the hidden class!).
  function showAnswer() {
    // TODO
  }
})();
