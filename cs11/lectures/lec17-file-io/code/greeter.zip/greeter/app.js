/**
 * @author Melissa Hovik
 * CSE154 Summer 2019
 * Lecture 17: More Node.js and File I/O
 *
 * The Greeter API says hello! An example to show serving static files
 * in a Node.js project and fetch from a webservice (see public/greeter.js).
 */
"use strict";
const express = require("express");
const app = express();

// Use static midddleware to set the directory to serve static files
app.use(express.static("public"));

app.get("/", (req, res) => {
  res.type("text"); // equivalent to res.set("Content-type", "text/plain");
  res.send("Hello!");
});

app.get("/:name", (req, res) => {
  let name = req.params.name;
  res.type("text");
  res.send("Hello " + name + "!");
});

const PORT = process.env.PORT || 8000;
app.listen(PORT);
